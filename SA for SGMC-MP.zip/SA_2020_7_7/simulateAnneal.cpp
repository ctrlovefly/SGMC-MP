/*# Last modified: 2020-08-05 19:02
#
# Filename: simulateAnneal.cpp
#
# Description: SA-based algorithm for the SGMC-MP
=============================================================================*/

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <vector>
#include <Ctime>
#include <fstream>
#include <SDKDDKVer.h>
#include <stdio.h>
#include <tchar.h>
#include <sstream>
using namespace std;
#define candidate_sat 15
#define candidate_station 1655
#define sat 10
#define station 20
#define demand 565
#define period 3
#define swath 45

struct solution_sat{
	int numsat;
	int numroll[period];
};//satellite swath element
struct solution{
	int chromostation[station];
	solution_sat ss[sat];
	double m_swap[station];
};//solution

solution sl;//current solution
double cover1[candidate_station][demand];//a coverage relation matrix between stationay sensors and demand objects
double cover2[period][candidate_sat][swath][demand];//a coverage relation matrix between strips and demand objects
double O_old=0;//fitness value of the current solution 
double O_new=0;//fitness value of the new trial solution
vector<int> f[3][15];//strip types
double all_demand_1[565];//demand area

//compute the fitness value of a solution
double objective_fun_both(solution sl){
	int objec=0;

	for (int i = 0; i < demand; i++)
	{
		double best_fitness_1 = 0;
		double best_fitness_2 = 0;
		double best_fitness_3 = 0;
			for (int j = 0; j <station; j++)
		{
			if (cover1[sl.chromostation[j]][i] >0)
			{
				for (int q = 0; q < sat; q++)
				{
					if (cover2[0][sl.ss[q].numsat][sl.ss[q].numroll[0]][i] >0)
					{
						best_fitness_1 =cover2[0][sl.ss[q].numsat][sl.ss[q].numroll[0]][i];//Cover2
					}	
					if (cover2[1][sl.ss[q].numsat][sl.ss[q].numroll[1]][i] >0)
					{
						best_fitness_2 =cover2[1][sl.ss[q].numsat][sl.ss[q].numroll[1]][i];//Cover2
					}	
					if (cover2[2][sl.ss[q].numsat][sl.ss[q].numroll[2]][i] >0)
					{
						best_fitness_3 =cover2[2][sl.ss[q].numsat][sl.ss[q].numroll[2]][i];//Cover2
					}
				}
			}
		}
		objec=objec+best_fitness_1+best_fitness_2+best_fitness_3;
	}
	return objec;
}


//generate a initial solution (satellite swath segment) and compute the fitness value of the initial solution
void initial_sat(){
	int num_1[candidate_sat];
	int num_2[swath];
	int p = candidate_sat-1;
	int q = swath-1;
	for (int i = 0; i < candidate_sat; i++)
	{
		num_1[i] = i;
	}
	for(int i=0; i<swath;i++)
	{
		num_2[i]=i;
	}
	int n;
	for (int i=0;i<sat;i++)
	{
		
		if(p==0)
		{
			n=0;
		}
		else
		{
			n=rand()%p+1;
		}
		
		sl.ss[i].numsat=num_1[n];//randomly create the elements of the first row representing satellite types
		int tmp = num_1[n];      //avoid repetition
		num_1[n] = num_1[p];
		num_1[p] = tmp;
		p--; 
		for (int j = 0; j < period; j++)
		{
			if( f[j][sl.ss[i].numsat].size()!=0)
			{
				n=rand()% f[j][sl.ss[i].numsat].size();
				sl.ss[i].numroll[j] = f[j][sl.ss[i].numsat][n];
			}
			else
			{
				n=rand()% q+1;
				sl.ss[i].numroll[j]=num_2[n];
				tmp = num_2[n];               
				num_2[n] = num_2[q];
				num_2[q] = tmp;
				q--; 
			}			
		}
	}	
	O_old=objective_fun_both(sl);
}


//compute the current fitness value for a greedy-add process 
double calculate_fit_array(int current_station[])
{
	double best_fitness_1;
	double ind_fitness = 0;
	for (int i = 0; i <= demand; i++)
	{
		best_fitness_1 = 0;
		for (int j = 0; j <station; j++)
		{
			if(current_station[j]<0)
			{
				break;
			}
			if (cover1[current_station[j]][i] >0)
			{
				best_fitness_1 =cover1[current_station[j]][i];
			}		
		}
		ind_fitness += best_fitness_1;
	}
	return ind_fitness;
}


//compute the added fitness value for a greedy-add process 
double calculate_fit_add_nonvec(int current_station[],int index)
{
	int flag_demand[demand];
	for (int i = 0; i < station; i++)
	{
		for (int j = 0; j < demand; j++)
		{
			if(cover1[current_station[i]][j]>0)
			{
				flag_demand[j]=1;
			}
		}
	}
	double cover_area=0;
	for (int i = 0; i < demand; i++)
	{
		if(cover1[index][i]>0 && flag_demand[i]!=1)
		{
			cover_area=cover_area+cover1[index][i];
		}
	}
	return cover_area;
}


void random(int a[], int n)
{
   int index, tmp, i;
   srand(time(NULL));
   for (i = 0; i <n; i++)
    {
       index = rand() % (n - i) + i;
       if (index != i)
         {
            tmp = a[i];
            a[i] = a[index];
            a[index] = tmp;
         }
    }
 }


//generate a initial solution (the stationary sensor segment)
void initial_facility_3()
{
	int num[candidate_station];
	int r = candidate_station - 1;
	int n;
	int tmp;
	for (int i = 0; i < candidate_station; i++)
	{
		num[i] = i;
	}
	double odd_cover;
	double new_cover;

	int ran=rand()%r+1;
	sl.chromostation[0]=num[ran];
	for (int i = 1; i < station; i++)
	{
		int current_station[station];
		n = rand() % r + 1;    
		for(int j=0; j<i;j++)
		{
			current_station[j]=sl.chromostation[j];
		}
		odd_cover = calculate_fit_array(current_station);
		double temp_cover=0;
		double temp_maxcover=0;
		int index_maxcover=0;
		int flag=0;
		for(int j=0;j<=r;j++)//Greedy-Add process
		{
			flag=0;
			if (num[j]!=-1)
			{
				temp_cover=calculate_fit_add_nonvec(current_station,num[j]);
			}
			else
			{
				continue;
			}
			if(temp_cover>=temp_maxcover)
			{
				temp_maxcover=temp_cover;
				index_maxcover=num[j];
			}
		}
		sl.chromostation[i] = index_maxcover;        

		tmp = num[n];             //avoid repetition
		num[n] = num[r];
		num[r] = tmp;
		random(num,r);
		r--;                     
	}
}


//change the element in the stationary sensor segment of a solution
solution change_facility(solution temp_sl)
{
	int num[candidate_station];
	for (int i = 0; i < candidate_station; i++)
	{
		num[i]=i;
	}
	int *distinct=new int[candidate_station-station];
	for (int i = 0; i < station; i++)
	{
		if(temp_sl.chromostation[i]==num[temp_sl.chromostation[i]])
		{
			num[temp_sl.chromostation[i]]=-1;
		}
	}
	int temp_num=0;
	for (int i = 0; i < candidate_station; i++)
	{
		if(num[i]!=-1)
		distinct[temp_num++]=num[i];
	}
	int r=rand()%(candidate_station-station); 
	int o=rand()%station;
	temp_sl.chromostation[o]=distinct[r];
	delete[]distinct;
	return temp_sl;
}


//change the element in the satellite swath segment of a solution
solution change_sat(solution temp_sl)
{
	if((double)(rand()%101)/101<0.3&&candidate_sat-sat>0)//change the satellite types and swath types
	{
		int num[candidate_sat];
		for (int i = 0; i < candidate_sat; i++)
		{
			num[i]=i;
		}
		int *distinct=new int[candidate_sat-sat];
		for (int i = 0; i < sat; i++)
		{
			if(temp_sl.ss[i].numsat==num[temp_sl.ss[i].numsat])
			{
				num[temp_sl.ss[i].numsat]=-1;
			}
		}
		int temp_num=0;
		for (int i = 0; i < candidate_sat; i++)
		{
			if(num[i]!=-1)
			distinct[temp_num++]=num[i];
		}
		int r=rand()%(candidate_sat-sat);
		int o=rand()%sat;
		temp_sl.ss[o].numsat=distinct[r];
		delete[]distinct;
		int mutation_time=sat/2;
		for(int p=0;p<mutation_time;p++)
		{
			int index = rand() % (sat);
			int period_index=rand() % (period);
			int candidates_2[swath];
			for (int i = 0; i < swath; i++)
			{
				candidates_2[i] = i;
			}
			candidates_2[temp_sl.ss[index].numroll[period_index]] = -1;
			//candidates.erase(candidates.begin() + m_genes[i]-1);

			if(f[period_index][temp_sl.ss[index].numsat].size()!=0)
			{
				int n=rand()% f[period_index][temp_sl.ss[index].numsat].size();
				temp_sl.ss[index].numroll[period_index] =f[period_index][temp_sl.ss[index].numsat][n];			
			}
			else
			{
				while (1)
				{
					int site = rand() % (swath);
					if(candidates_2[site]!=-1)
					{
						temp_sl.ss[index].numroll[period_index] = candidates_2[site];
						break;
					}	
				}	
			}
		}
	}
	else//only change swath types
	{
		int mutation_time=sat/2;
		for(int p=0;p<mutation_time;p++)
		{
			int index = rand() % (sat);
			int period_index=rand() % (period);
			int candidates_2[swath];
			for (int i = 0; i < swath; i++)
			{
				candidates_2[i] = i;
			}
			candidates_2[temp_sl.ss[index].numroll[period_index]] = -1;
			//candidates.erase(candidates.begin() + m_genes[i]-1);

			if(f[period_index][temp_sl.ss[index].numsat].size()!=0)
			{
				int n=rand()% f[period_index][temp_sl.ss[index].numsat].size();
				temp_sl.ss[index].numroll[period_index] =f[period_index][temp_sl.ss[index].numsat][n];			
			}
			else
			{
				while (1)
				{
					int site = rand() % (swath);
					if(candidates_2[site]!=-1)
					{
						temp_sl.ss[index].numroll[period_index] = candidates_2[site];
						break;
					}	
				}	
			}
		}
	}
	return temp_sl;
}


int L = 200000;
double e=0.000001,at=0.99,T=100;//tolerance value tol, cooling rate ��,and initial temperature T
double pc=0.3;

//main process of the SA 
void Simulated_Annealing_sat(){ 
	srand((unsigned)time(NULL)); 
	int count=0;
	int N=500;//maximum iteration number
	int Flag=0;
	while (L--)
	{
		
		while (count<N)
		{
			solution temp_sl=sl;//the new trial solution
			double temp_u=(double)(rand() % 101) / 101;
			if (temp_u < pc)//generate a new trial solution
			{
				temp_sl=change_facility(temp_sl);
				temp_sl=change_sat(temp_sl);
			}
			else if(temp_u >=pc && temp_u<=0.8)
			{
				temp_sl=change_sat(temp_sl);
			}
			else
			{
				temp_sl=change_facility(temp_sl);
			}
			O_new=objective_fun_both(temp_sl);
			count++;
			double df=O_new-O_old;		
			double sj=rand()%10000;     
			sj/=10000;//sj is a random number between 0 and 1 

			if(df>0)//if the trial solution is better, the trial solution and the current solution are exchanged
			{
				sl=temp_sl;
				O_old=O_new;
				count=0;
			}
			else{
				if (exp(df/T)>sj)
				{
					sl=temp_sl;
					O_old=O_new;
				}	
			} 
		}
		T*=at;  //cooling temperature T=T*at
		count=0;
		cout<<T<<endl;
		cout<<O_old<<endl;		
        if(T<e) break;  //if T<e, the SA process stops
	}
}


vector<int> split2(string str,char del) //���ԡ���λ����::192:168:ABC::416��->��192 168 ABC 416��
{
    stringstream ss(str);
    string tok;
    vector<int> ret;
    while(getline(ss,tok,del))
    {
        if(tok > "")
            ret.push_back(stoi(tok));
    }
    return ret;
};

//read txt in default fold of the codes  //"....\sa_2020_7_7\SA_2020_7_7"
void read_txt()
{
	ifstream Co1("PIPS.txt"); 
	for (int i = 0; i < candidate_station; i++)
	{
		for (int j = 0; j < demand; j++)
		{
			Co1 >> cover1[i][j];
		}
	}
	Co1.close();

	ifstream Co1swath("period1.txt"); 
	for (int i = 0; i < candidate_sat; i++)
	{
		for (int j = 0; j < swath; j++)
		{
			for(int z = 0;z < demand; z++)
			{
				Co1swath >> cover2[0][i][j][z];
			}
		}
	}
	Co1swath.close();

	ifstream Co1swath1("period2.txt"); 
	for (int i = 0; i < candidate_sat; i++)
	{
		for (int j = 0; j < swath; j++)
		{
			for(int z = 0;z < demand; z++)
			{
				Co1swath1 >> cover2[1][i][j][z];
			}
		}
	}
	Co1swath1.close();

	ifstream Co1swath2("period3.txt"); 
	for (int i = 0; i <  candidate_sat; i++)
	{
		for (int j = 0; j < swath; j++)
		{
			for(int z = 0;z < demand; z++)
			{
				Co1swath2 >> cover2[2][i][j][z];
			}
		}
	}
	Co1swath2.close();

	for(int z=0;z<period;z++)
	{
		stringstream ss1;
		ss1 << z+1; 
		ifstream file(ss1.str()+".txt");
		string str[15];
		int arraynum1=0;
		if(file.is_open())
		{
			for(int i=0;i<15;i++)
			{
				getline(file,str[arraynum1]);
				arraynum1++;
			}
		}
		//vector<int> f[15];
		int n=0;
		for(int j=0;j<15;j++)
		{
			if(!str[j].empty())
			{
				f[z][j]=(split2(str[j],','));
					n++;
			}
			else
			{
				
			}
		}		
	}
}

string getTime()
{
	time_t timep;
	time(&timep);
	char tmp[64];
	strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S", localtime(&timep));
	return tmp;
}

int main(){
	read_txt();
	int runtime=10;
	for (int i = 0; i < runtime; i++)
	{
		srand((unsigned)time(NULL));
		T=100;
		L = 200000;
		cout << getTime()<<" ";
		initial_facility_3();
		initial_sat();
		Simulated_Annealing_sat();
		cout << getTime() << " ";//solving time
		cout<<O_old<<endl;
	}
	system("pause");
	return 0;
}